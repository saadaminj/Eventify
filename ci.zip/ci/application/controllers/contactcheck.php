<?php
class Contactcheck extends CI_Controller
{
 	public function index()
 	{
 		$this->load->view('Default_Webpage.html');
 	}
 	public function contact()
 	{
 		$this->load->view('index.html');
 	}
}
?>