<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About FMS</h1>
					<h3>Mission</h3>
					<P>FMS as known as “FAST Management Society” is a society founded by the FSM(BBA Department). Our main objective is to evince better management skills in the real world job environment. We solely focus on our undergrads, as our goal is for every individ</P>

				
							
							
				</div>
			</div>
			</div>
			
		</div>
	</div>
	