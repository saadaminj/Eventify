<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About WEBMASTERS</h1>
					<h3>Mission</h3>
							<p>TheWebmasters is a team of highly talented students, whose primary function is the continual maintenance and enhancement of the NUCES-FAST Karachi campus website. This student committee also conducts seminars, workshops and competitions in the areas of web development, website & graphic design, and open source technology. The team comprises of hand picked individuals from the fields of Web Development, Web Designing, Content Writing and Animation who are continually on the go for the propagation of technology at NUCES-FAST Karachi!</p>
							
							
							<br>
							<h4>Founded in 2011</h4>
							
				</div>
			</div>
			</div>
			
		</div>
	</div>
	