<?php
class ABC extends CI_model
{
	public function get_value()
	{	
		//HOW TO SEND STRING
		return "Azhan Ali";
		//HOW TO SEND ARRAY
	// $data = array(
 //               'title' => 'My Title',
 //               'heading' => 'My Heading',
 //               'message' => 'My Message'
 //          		);
	
	// return $data;
	}
} 
?>