<!DOCTYPE html>
<html>
<head>
	<title>THIS IS OUR FRONT END</title>
</head>
<body>
	<h1> Hello EVERYONE</h1>
	<h3>We have sent this text from PHP MODELS through controller</h3>
	<?php
	print_r($value);
	?>
</body>
</html>