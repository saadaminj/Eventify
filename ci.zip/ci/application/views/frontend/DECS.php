<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About DECS</h1>
							<p>DECS has always been on the go in planning extra-curricular activities such as picnics and melas for the FASTians which prove to be both exhilarating and exclusive. The annual picnic, Drama Competition, Annual Study Tour, and the very formal Annual Dinner are some elite events organized by DECS which almost ALWAYS rock!  

This is the only official fan page of DECS. All the updates and news about the events of DECS will be shared here!</p>
<h4>EVENTS</h4>
<li>Drama Competition</li>
<li>Annual Study Tour</li>
<li>Annual Dinner</li>
<li>Anuual Picnic</li>


							
				</div>
			</div>
			</div>
			
		</div>
	</div>
	
