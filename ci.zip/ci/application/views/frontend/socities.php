	
	<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<h1 align="center">NU Societies</h1><br>
				<div class="container-fluid proj-bottom">
			<div class="row">
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
				<a ><img src="<?php echo base_url().'assets/frontend/images/decspf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>DECS</h3>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a ><img src="<?php echo base_url().'assets/frontend/images/acmpf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>ACM</h3>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a ><img src="<?php echo base_url().'assets/frontend/images/SPORTICS1.png';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>Sportics</h3>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="<?php echo base_url().'assets/frontend/images/fmspf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>Fast-Management-Society</h3>
					</a>
				</div>
				
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					
					<a><img src="<?php echo base_url().'assets/frontend/images/TWM.png';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>THE WEBMASTERS</h3>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					
					<a href="#"><img src="<?php echo base_url().'assets/frontend/images/cbspf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>Character-Building-Society</h3>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
						<a href="#"><img src="<?php echo base_url().'assets/frontend/images/tlcpf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>The Literary Club</h3>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
					<a href="#"><img src="<?php echo base_url().'assets/frontend/images/ieeepf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>IEEE</h3>
					</a>
				</div>
				<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
				
						<a ><img src="<?php echo base_url().'assets/frontend/images/tncpf.jpg';?>" alt="IMG UNABLE TO LOAD" class="img-responsive">
						<h3>Think & Create</h3>
					</a>
				</div>
				
			</div>
		</div>
	</div> </div> </div>
