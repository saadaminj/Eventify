


   <!-- Bootstrap Core Js -->
   <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/bootstrap/js/bootstrap.js"></script>




    <!-- Select Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Jquery Validation Plugin Css -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-validation/jquery.validate.js"></script>

    <!-- JQuery Steps Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-steps/jquery.steps.js"></script>

    <!-- Sweet Alert Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/sweetalert/sweetalert.min.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/raphael/raphael.min.js"></script>


    <!-- ChartJs -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/chartjs/Chart.bundle.js"></script>



    <!-- Sparkline Chart Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-sparkline/jquery.sparkline.js"></script>

<!-- Jquery DataTable Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

<!-- Bootstrap Notify Plugin Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>plugins/bootstrap-notify/bootstrap-notify.js"></script>

  <!-- TinyMCE -->
<script src="<?php echo SITE_URL.'assets/admin/';?>plugins/tinymce/tinymce.js"></script>


    <!-- Custom Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>js/admin.js"></script>

    <script src="<?php echo SITE_URL.'/assets/admin/';?>js/pages/tables/jquery-datatable.js"></script>
    <script src="<?php echo SITE_URL.'/assets/admin/';?>js/pages/ui/dialogs.js"></script>




    <!-- Demo Js -->
    <script src="<?php echo SITE_URL.'/assets/admin/';?>js/demo.js"></script>


    <script src="<?php echo SITE_URL.'/assets/admin/';?>js/pages/forms/form-validation.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <script>
       $.validate();
   </script>

   <script src="<?php echo SITE_URL.'assets/admin/';?>js/global.js"></script>
   <script src="<?php echo SITE_URL.'assets/admin/';?>js/pages/forms/editors.js"></script>
   <!-- Ckeditor -->
    <script src="<?php echo SITE_URL.'assets/admin/';?>plugins/ckeditor/ckeditor.js"></script>

   
</body>

</html>