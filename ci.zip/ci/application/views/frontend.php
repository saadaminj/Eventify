<!DOCTYPE html>
<html>
<head>
	<title>WELCOME</title>
</head>
<body>
	<?php
	print_r($page_data); 
	//echo $page_data['title'];
	?>
	<p>HEY</p>

</body>
</html>