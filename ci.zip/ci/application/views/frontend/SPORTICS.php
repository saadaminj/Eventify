<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About Sportics</h1>
					<p>A society that keeps the sportsman spirit alive in all FASTIAN GEEKS!</p>
					<p>The society for those who love sports at FAST-Karachi. Let it be outdoor sports: Volley Ball, Cricket, Throw-ball, Basketball, and Football or the indoor: Table-tennis, Snooker, Foosball. For many past years, successively organizing the Intra and Inter University Competitions. The creators of the most anticipated events at FAST. The path to any FASTIAN's sports success. The heartbeat of FAST, SPORTICS!</p>	
					<h4>Events</h4>
					<li>Intra University Competitions</li>
					<li>Inter University Competitions</li>
					<br>
					<h4>Sports</h4>
					<li>Volley Ball</li>
					<li>Throw-Ball</li>
					<li>Basketball</li>
					<li>Football</li>
					<li>Foosball</li>
					<li>Snooker</li>
					</div>
				</div>
			</div>
		</div>
</div>
	