
	<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About CBS</h1>
					<h3>Mission</h3>
					<P>CBS helps students improve themselves by showing a better character. We enable students to know and act on their responsibilities in different life roles.</P>
							<li> To help individuals become better version of themselves.</li>
							<li>To enable students to take on the responsibility.</li>
							<li>To educate young minds the importance and potential of a good a character.</li>
							
							<br>
							
							
				</div>
			</div>
			</div>
			
		</div>
	</div>