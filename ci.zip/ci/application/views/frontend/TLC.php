	<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About TLC</h1>
					<h3>Mission</h3>
					<P>TLC is only the most active, the most happening and the most classy society at FAST, Karachi. With events like Xpressions, Zauq, Agha Hasan Abedi Declamation Contest, Intra-MUN, Parliamentary Debates and an annual magazine called the "localhost"; TLC tries to inspire a literary and artistic taste in the techies, geeks and nerds of FAST. TLC aims to turn the scientists of FAST into visionaries; because only true visionaries are able to say that “Code is poetry” and “Science is art”.</P>

					<h4>Events</h4>
					<li> Declamation Contest</li>
					<li>Intra-MUN, Parliamentary Debates</li>
					<li>Xpressions</li>
					<br>
					<h4>Founded in 2007</h4>
							
							
							
				</div>
			</div>
			</div>
			
		</div>
	</div>
