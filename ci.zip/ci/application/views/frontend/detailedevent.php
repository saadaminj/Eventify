<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					
					
				</div>
				<div class="col-md-12 animate-box">
					<div class="price-box">
					<h1>About EVENT</h1>
					<br><br>
					<h3> Society :- <?php echo $pagedata[0]['Society']?></h3>
					<h4>  Created At :- <?php echo $pagedata[0]['created_at']?></h4>
					<h5>Description:-<?php echo $pagedata[0]['description']?> </h5>

				
							
							
				</div>
			</div>
			</div>
			
		</div>
	</div>
	