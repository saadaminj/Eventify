<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					

				</div>
				<div class="col-md-6 animate-box">
					<div class="price-box">
					<h1>About ACM</h1>
							<p>The ACM Student Chapter at FAST-NUCES Karachi Campus is dedicated to the promotion of computing education, research and development.</p>
							<p>At ACM-NUCES KHI Chapter, you join a team that aims to change the methodology with which students approach computing and technology. We do our utmost to deliver the latest, and most innovative educational and professional development resources that our members require to strengthen their skill sets and enrich their careers. Most importantly, we take your view into consideration.</p>
							<P>At ACM-NUCES KHI Chapter. It’s all about YOU! Join Us and enjoy the following truly unique benefits
								<li>Become a part of the energetic international ACM community.</li>
								<li>Meet Entrepreneurs/Innovators leading Pakistan into a bright new future.</li>
								<li> Learn from computing field's premier ACM Digital Library.</li>
								<li>Expand your knowledge by using the ACM TechPack.</li>
								<li>Take part in regional or international seminars and competitions.</li>
								<li>Collaborate with the industry to work on the latest projects.</li>
							</P>
							<br>
							<h4>Events</h4>
							<li>Procom</li>
							<li>Developers Day</li>
				</div>
			</div>
			</div>
			
		</div>
	</div>
	